//
//  CFMSdk_Test.h
//  CFMSdk_Test
//
//  Created by Carolina Franco on 8/1/18.
//  Copyright © 2018 Carolina Franco. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CFMSdk_Test.
FOUNDATION_EXPORT double CFMSdk_TestVersionNumber;

//! Project version string for CFMSdk_Test.
FOUNDATION_EXPORT const unsigned char CFMSdk_TestVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CFMSdk_Test/PublicHeader.h>


